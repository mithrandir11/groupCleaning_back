@extends('layouts.admin')

@section('content')
<livewire:management.service-create>
@endsection


