<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ServiceOptionValue extends Model
{
    protected $guarded = [];
}
