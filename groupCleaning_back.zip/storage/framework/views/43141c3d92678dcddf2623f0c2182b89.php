<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <title><?php echo e($title ?? 'پنل متخصص'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body>
     


    <div class="px-1 lg:px-4   ">

        <div class="py-12 flex gap-x-6">
            <?php if($showSidebar ?? true): ?>
                <?php if (isset($component)) { $__componentOriginalf37810c4d2edea24feb94b27e6da8d08 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf37810c4d2edea24feb94b27e6da8d08 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar.worker','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar.worker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf37810c4d2edea24feb94b27e6da8d08)): ?>
<?php $attributes = $__attributesOriginalf37810c4d2edea24feb94b27e6da8d08; ?>
<?php unset($__attributesOriginalf37810c4d2edea24feb94b27e6da8d08); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf37810c4d2edea24feb94b27e6da8d08)): ?>
<?php $component = $__componentOriginalf37810c4d2edea24feb94b27e6da8d08; ?>
<?php unset($__componentOriginalf37810c4d2edea24feb94b27e6da8d08); ?>
<?php endif; ?>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        
        

    </div>
</body>
</html><?php /**PATH D:\group_cleaning\groupCleaning_back\resources\views/layouts/worker.blade.php ENDPATH**/ ?>