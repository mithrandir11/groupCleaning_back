

<?php $__env->startSection('content'); ?>


  <div class="h-screen w-full  mx-auto  p-3">
    <section class="flex justify-center   ">
      <div class="mx-auto max-w-lg w-full px-6 lg:px-8  py-16 ">
        
        <div class="rounded-2xl bg-white border lg:p-11 p-7">
          <?php if(session()->has('otp')): ?>
          <div class="bg-green-200 text-green-800 rounded p-3 my-3">
            کد ورود  : <strong><?php echo e(session('otp')); ?></strong>
          </div>
          <?php endif; ?>
          <form method="POST" action="<?php echo e(route('worker.verify.otp')); ?>" class=" mx-auto">
            <?php echo csrf_field(); ?>
            <img src="<?php echo e(asset('images/logo_full.png')); ?>" alt="pagedone logo" class="mx-auto lg:mb-11 mb-8 object-cover">
            <label for="otp" class="block mb-2 text-sm font-medium text-gray-900">کد تایید</label>
            <input name="otp" type="number" class="w-full h-12 text-gray-900 placeholder:text-gray-400 text-lg font-normal leading-7 rounded-lg border-gray-300 border shadow-sm focus:outline-none px-4 mb-6" >
            <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <button type="submit" class="flex  items-center justify-center text-white bg-blue-600 hover:bg-blue-700 duration-200 rounded-lg text-sm px-5 py-2.5 text-center ">ورود به حساب</button>
          </form>

         
          <form action="<?php echo e(route('worker.resend.otp')); ?>" method="POST" class="mt-4 text-end ">
            <?php echo csrf_field(); ?>
            <button type="submit" class="text-gray-500 text-sm underline">
                ارسال مجدد کد تایید
            </button>
        </form>
        </div>
  
      </div>
    </section>
  </div>



                                            
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.worker', ['showSidebar' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\group_cleaning\groupCleaning_back\resources\views/auth/worker/verify-otp.blade.php ENDPATH**/ ?>