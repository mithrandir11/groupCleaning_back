<ul class="list-none">
  <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li class="mb-6">
          <div class="flex items-center justify-between">
              <div class="flex items-center">
                  <?php echo e($menu->name); ?>

                  <span class="text-sm text-gray-500 mr-2">
                    (<?php echo e(($menu->slug)); ?>)
                  </span>
              </div>
              <div>
                  <a href="<?php echo e(route('admin.menu.edit', $menu)); ?>"  type="button" class="bg-yellow-100 py-1 px-4 text-black text-xs rounded-full font-semibold transition-all duration-200 ml-2 inline-flex gap-x-1">
                    
                      
                      ویرایش
                  </a>

                  <form action="<?php echo e(route('admin.menu.delete', $menu)); ?>" method="POST" class="inline">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('DELETE'); ?>
                      <button type="submit" class="bg-red-100 py-1 px-4 text-black text-xs rounded-full font-semibold transition-all duration-200 inline-flex gap-x-1" onclick="return confirm('آیا از حذف این منو مطمئن هستید؟')">
                        
                        حذف
                      </button>
                  </form>
              </div>
          </div>

          <?php if($menu->children && $menu->children->isNotEmpty()): ?>
              <div class="mr-4 border-r border-gray-300 pr-4 mt-6">
                  <?php if (isset($component)) { $__componentOriginalce8b8e526fbecc53ba331c796c00f9a3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce8b8e526fbecc53ba331c796c00f9a3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.menu.partials','data' => ['menus' => $menu->children]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu.partials'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['menus' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($menu->children)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce8b8e526fbecc53ba331c796c00f9a3)): ?>
<?php $attributes = $__attributesOriginalce8b8e526fbecc53ba331c796c00f9a3; ?>
<?php unset($__attributesOriginalce8b8e526fbecc53ba331c796c00f9a3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce8b8e526fbecc53ba331c796c00f9a3)): ?>
<?php $component = $__componentOriginalce8b8e526fbecc53ba331c796c00f9a3; ?>
<?php unset($__componentOriginalce8b8e526fbecc53ba331c796c00f9a3); ?>
<?php endif; ?>
              </div>
          <?php endif; ?>
      </li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>



<?php /**PATH D:\group_cleaning\groupCleaning_back\resources\views/components/menu/partials.blade.php ENDPATH**/ ?>