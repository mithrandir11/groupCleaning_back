

<?php $__env->startSection('content'); ?>
<div class=" overflow-x-auto  grow">

    

    <table class="w-full text-sm text-left rtl:text-right text-gray-500 ">
        <thead class="text-xs text-gray-700 uppercase bg-gray-50  ">
            <tr>
                <th scope="col" class="px-6 py-3">
                    ردیف
                </th>
                <th scope="col" class="px-6 py-3">
                    تاریخ
                </th>
                <th scope="col" class="px-6 py-3">
                    نام
                </th>
                <th scope="col" class="px-6 py-3">
                    پیام
                </th>
                <th scope="col" class="px-6 py-3 text-center">
                    جزئیات
                </th>
            </tr>
        </thead>
        
        <tbody>
            <?php $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="odd:bg-white  even:bg-gray-50  border-b ">
                <th scope="row" class="px-6 py-4  text-gray-900 whitespace-nowrap ">
                    <?php echo e($conversations->total() - ($conversations->perPage() * ($conversations->currentPage() - 1) + $index)); ?>

                </th>
                <td class="px-6 py-4">
                    <?php echo e($conversation->created_at); ?>

                </td>
                <td class="px-6 py-4">
                    <?php echo e($conversation->user->name); ?>

                </td>
                <td class="px-6 py-4">
                    <?php echo e($conversation->messages->last()->message); ?>

                </td>
                
                
                <td class="px-6 py-4 text-center">
                    <a href="<?php echo e(route('admin.messages.show', $conversation)); ?>" class="bg-blue-100 py-1 px-4 text-black text-xs rounded-full font-semibold transition-all duration-200">
                        مشاهده
                        <?php if($conversation->unread_messages_count > 0): ?>
                        <span class="bg-blue-500 text-white rounded-full px-2.5 py-1"><?php echo e($conversation->unread_messages_count); ?></span>
                        <?php endif; ?>
                    </a>
                    <form action="<?php echo e(route('admin.messages.delete', $conversation)); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" onclick="return confirm('آیا از حذف این آیتم مطمئن هستید؟')" class="bg-red-100 mr-2 py-1 px-4 text-black text-xs rounded-full font-semibold transition-all duration-200">
                            حذف
                        </button>
                    </form>
                </td>
                

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
           
        </tbody>
    </table>  

    

</div>                                       
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\group_cleaning\groupCleaning_back\resources\views/management/messages/index.blade.php ENDPATH**/ ?>