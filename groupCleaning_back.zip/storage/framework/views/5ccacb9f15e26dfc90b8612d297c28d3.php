

<?php $__env->startSection('content'); ?>
<div class=" overflow-x-auto  grow">

 

    <table class="w-full text-sm text-left rtl:text-right text-gray-500 ">
        <thead class="text-xs text-gray-700 uppercase bg-gray-50  ">
            <tr>
                
                <th scope="col" class="px-6 py-3">
                    عنوان
                </th>
                <th scope="col" class="px-6 py-3">
                    پیام
                </th>
                <th scope="col" class="px-6 py-3">
                    تاریخ
                </th>
                
            </tr>
        </thead>
        
        <tbody>
            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="odd:bg-white  even:bg-gray-50  border-b ">
                
                <td class="px-6 py-4">
                    <?php echo e($notification->title); ?>

                </td>
                <td class="px-6 py-4">
                    <?php echo e($notification->message); ?>

                </td>
                <td class="px-6 py-4">
                    <?php echo e($notification->created_at); ?>

                </td>
 
                

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
           
        </tbody>
    </table>  

    <div class="mt-4">
        <?php echo e($notifications->links()); ?>

    </div>      

</div>                                       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.worker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\group_cleaning\groupCleaning_back\resources\views/worker/dashboard.blade.php ENDPATH**/ ?>