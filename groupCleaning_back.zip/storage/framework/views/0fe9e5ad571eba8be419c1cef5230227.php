

<?php $__env->startSection('content'); ?>
<div class=" overflow-x-auto  grow">


    
        
        
    

    
    
    <table class="w-full text-sm text-left rtl:text-right text-gray-500 ">
        <thead class="text-xs text-gray-700 uppercase bg-gray-50  ">
            <tr>
                <th scope="col" class="px-6 py-3">
                    تاریخ
                </th>
                <th scope="col" class="px-6 py-3">
                    کد متخصص
                </th>
                <th scope="col" class="px-6 py-3">
                   کل تسویه شده
                </th>
                <th scope="col" class="px-6 py-3">
                    کل درآمد
                </th>
                <th scope="col" class="px-6 py-3">
                    کل جریمه
                </th>
                <th scope="col" class="px-6 py-3">
                    کل بستانکاری
                </th>
                <th scope="col" class="px-6 py-3">
                    وضعیت متخصص
                </th>
                <th scope="col" class="px-6 py-3 text-center">
                    عملیات
                </th>
                
            </tr>
        </thead>
        
        <tbody>
            <?php if($report): ?>
            <tr class="odd:bg-white  even:bg-gray-50  border-b ">
                <td class="px-6 py-4">
                    <?php echo e($report->updated_at); ?> 
                </td>
                <td class="px-6 py-4">
                    <?php echo e($report->worker_id); ?> 
                </td>
                <td class="px-6 py-4">
                    <?php echo e(number_format($report->totalPaidAmountForWorker($worker_id))); ?> <span class="text-xs">تومان</span>
                </td>
                <td class="px-6 py-4">
                    <?php echo e(number_format($report->totalIncomeAmountForWorker($worker_id))); ?> <span class="text-xs">تومان</span>
                </td>
                <td class="px-6 py-4">
                    <?php echo e(number_format($report->totalPenaltyAmountForWorker($report->worker_id))); ?> <span class="text-xs">تومان</span>
                </td>
                <td class="px-6 py-4">
                    <?php echo e(number_format($report->totalCreditAmountForWorker($worker_id))); ?> <span class="text-xs">تومان</span>
                </td>
                <td class="px-6 py-4">
                    <?php echo e(__('fa.status.'.$report->balanceStatus($report->worker_id))); ?>

                </td>
                <td class="px-6 py-4 text-center">
                    <a href="<?php echo e(route('worker.finance.details')); ?>"  type="button" class="bg-blue-100 py-1 px-4 text-black text-xs rounded-full font-semibold transition-all duration-200">
                        مشاهده جزئیات
                    </a>
                </td>
            </tr> 
            <?php endif; ?>
                 
           
        </tbody>
    </table>  

    

</div>



                                            
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.worker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\group_cleaning\groupCleaning_back\resources\views/worker/finance/index.blade.php ENDPATH**/ ?>