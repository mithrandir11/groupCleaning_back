

<?php $__env->startSection('content'); ?>
<div class=" overflow-x-auto  grow">


    
    
    <table class="w-full text-sm text-left rtl:text-right text-gray-500 ">
        <thead class="text-xs text-gray-700 uppercase bg-gray-50  ">
            <tr>
                <th scope="col" class="px-6 py-3">
                    key
                </th>
                <th scope="col" class="px-6 py-3">
                    value
                </th>
                <th scope="col" class="px-6 py-3">
                    توضیحات
                </th>
                <th scope="col" class="px-6 py-3 text-center">
                    عملیات
                </th>
            </tr>
        </thead>
        
        <tbody>
            <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="odd:bg-white  even:bg-gray-50  border-b ">

                <td class="px-6 py-4">
                    <?php echo e($setting->key); ?>

                </td>

                <td class="px-6 py-4">
                    <?php echo e($setting->value); ?>

                </td>

                <td class="px-6 py-4">
                    <?php echo e($setting->description); ?>

                </td>

                <td class="px-6 py-4 text-center">
                    <a href="<?php echo e(route('admin.settings.edit', $setting)); ?>" class="bg-yellow-100 py-1 px-4 text-black text-xs rounded-full font-semibold transition-all duration-200">
                        ویرایش
                    </a>

                    
                   
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
           
        </tbody>
    </table>  

    <div class="mt-4">
        <?php echo e($settings->links()); ?>

    </div>      

</div>



                                            
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\group_cleaning\groupCleaning_back\resources\views/management/settings/index.blade.php ENDPATH**/ ?>