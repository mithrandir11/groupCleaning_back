<ul class="list-none">
  <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li class="mb-6">
          <div class="flex items-center justify-between">
              <div class="flex items-center">
                  <?php echo e($menu->name); ?>

                  <span class="text-sm text-gray-500 mr-2">
                    (<?php echo e(($menu->slug)); ?>)
                  </span>
              </div>
              <div>
                  <a href="<?php echo e(route('admin.suggestedPages.show', $menu)); ?>"  type="button" class="bg-blue-100 py-1 px-4 text-black text-xs rounded-full font-semibold transition-all duration-200 ml-2 inline-flex gap-x-1">
                    
                      
                      مشاهده
                  </a>

                  
              </div>
          </div>

          <?php if($menu->children && $menu->children->isNotEmpty()): ?>
              <div class="mr-4 border-r border-gray-300 pr-4 mt-6">
                  <?php if (isset($component)) { $__componentOriginal7aa8aec3fe7657d4f40af1d1725fb746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7aa8aec3fe7657d4f40af1d1725fb746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.suggested-pages.partials','data' => ['menus' => $menu->children]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('suggested-pages.partials'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['menus' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($menu->children)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7aa8aec3fe7657d4f40af1d1725fb746)): ?>
<?php $attributes = $__attributesOriginal7aa8aec3fe7657d4f40af1d1725fb746; ?>
<?php unset($__attributesOriginal7aa8aec3fe7657d4f40af1d1725fb746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7aa8aec3fe7657d4f40af1d1725fb746)): ?>
<?php $component = $__componentOriginal7aa8aec3fe7657d4f40af1d1725fb746; ?>
<?php unset($__componentOriginal7aa8aec3fe7657d4f40af1d1725fb746); ?>
<?php endif; ?>
              </div>
          <?php endif; ?>
      </li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>



<?php /**PATH D:\group_cleaning\groupCleaning_back\resources\views/components/suggested-pages/partials.blade.php ENDPATH**/ ?>