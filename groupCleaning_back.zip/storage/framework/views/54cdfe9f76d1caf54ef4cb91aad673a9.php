

<?php $__env->startSection('content'); ?>
<div class=" overflow-x-auto  grow">

    <div class="flex justify-between items-center gap-x-3  ">
        <div class="max-w-sm w-full">   
            <label for="default-search" class="mb-2 text-sm font-medium text-gray-900 sr-only ">Search</label>
            <form action="<?php echo e(route('admin.orders.assignOrderToWorker.show', $order)); ?>" method="GET" class="relative">
                
                <div class="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
                    <svg class="w-4 h-4 text-gray-500 " aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
                    </svg>
                </div>
                <input name="search" type="text" id="default-search" class="block w-full p-3 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg outline-none  focus:border-blue-500" placeholder="نام  یا نام‌خانوادگی  یا  شماره تماس ..."  />
                <button type="submit" class="text-white absolute end-2 bottom-1.5 bg-gray-500 hover:bg-gray-600 duration-200  outline-none  font-medium rounded-lg text-xs px-3 py-2">جستجو</button>
            </form>
        </div>

        <a href="<?php echo e(route('admin.orders.show', $order)); ?>" class="flex items-center gap-x-2 border duration-200 rounded-lg text-sm px-4 py-2 ">
            بارگشت
            <svg width="20" height="20" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg" transform="rotate(0 0 0)">
                <path d="M3.57813 12.4981C3.5777 12.6905 3.65086 12.8831 3.79761 13.0299L9.7936 19.0301C10.0864 19.3231 10.5613 19.3233 10.8543 19.0305C11.1473 18.7377 11.1474 18.2629 10.8546 17.9699L6.13418 13.2461L20.3295 13.2461C20.7437 13.2461 21.0795 12.9103 21.0795 12.4961C21.0795 12.0819 20.7437 11.7461 20.3295 11.7461L6.14168 11.7461L10.8546 7.03016C11.1474 6.73718 11.1473 6.2623 10.8543 5.9695C10.5613 5.6767 10.0864 5.67685 9.79362 5.96984L3.84392 11.9233C3.68134 12.0609 3.57812 12.2664 3.57812 12.4961L3.57813 12.4981Z" fill="#343C54"/>
            </svg>
        </a>
    </div>

   

    
    
    <table class="w-full text-sm text-left rtl:text-right text-gray-500 mt-10">
        <thead class="text-xs text-gray-700 uppercase bg-gray-50  ">
            <tr>
                <th scope="col" class="px-6 py-3">
                    کد کاربر
                </th>
                <th scope="col" class="px-6 py-3">
                    نام
                </th>
                <th scope="col" class="px-6 py-3">
                    نام خانوادگی
                </th>
                <th scope="col" class="flex gap-x-1 items-center">

                    
                    <form class="max-w-lg flex">
                        <input name="search" type="text" id="default-search" class="block  p-2 text-xs text-gray-900 border border-gray-300 rounded-r-lg outline-none  focus:border-blue-500"  placeholder="مهارت ها ..." />
                        <button class="border border-r-0 border-gray-300 rounded-l-lg px-2 bg-gray-100 duration-200  hover:bg-gray-200" >
                            <svg width="20" height="20" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg" transform="rotate(0 0 0)">
                                <path d="M11.2498 5.75037C10.8356 5.75037 10.4998 6.08615 10.4998 6.50037C10.4998 6.91458 10.8356 7.25037 11.2498 7.25037C13.874 7.25037 16.0011 9.37718 16.0011 12.0004C16.0011 12.4146 16.3369 12.7504 16.7511 12.7504C17.1653 12.7504 17.5011 12.4146 17.5011 12.0004C17.5011 8.54842 14.7021 5.75037 11.2498 5.75037Z" fill="#343C54"/>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M2 11.9989C2 6.89126 6.14154 2.75098 11.25 2.75098C16.3585 2.75098 20.5 6.89126 20.5 11.9989C20.5 14.2836 19.6714 16.3747 18.2983 17.9883L21.7791 21.4695C22.072 21.7624 22.072 22.2372 21.7791 22.5301C21.4862 22.823 21.0113 22.823 20.7184 22.5301L17.2372 19.0486C15.6237 20.4197 13.5334 21.2469 11.25 21.2469C6.14154 21.2469 2 17.1066 2 11.9989ZM11.25 4.25098C6.96962 4.25098 3.5 7.72003 3.5 11.9989C3.5 16.2779 6.96962 19.7469 11.25 19.7469C15.5304 19.7469 19 16.2779 19 11.9989C19 7.72003 15.5304 4.25098 11.25 4.25098Z" fill="#343C54"/>
                                </svg>
                                
                        </button>
                    </form>

                </th>

                <th scope="col" class="px-6 py-3">
                    امتیاز
                </th>
                <th scope="col" class="px-6 py-3 ">
                    در حال انجام؟
                </th>
                <th scope="col" class="px-6 py-3 ">
                    کل سفارش
                </th>
                <th scope="col" class="px-6 py-3 ">
                    کمیسیون
                </th>
                <th scope="col" class="px-6 py-3 text-center">
                    عملیات
                </th>
               
            </tr>
        </thead>
        
        <tbody>
            <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr x-data="{ open: false }" v-for="(order, index) in data.data" class="odd:bg-white  even:bg-gray-50  border-b ">
                <td class="px-6 py-4">
                    <?php echo e($worker->id); ?>

                </td>
                <td class="px-6 py-4">
                    <?php echo e($worker->name); ?>

                </td>
                <td class="px-6 py-4">
                    <?php echo e($worker->family); ?>

                </td>
                <td class="px-6 py-4">
                    <?php if(!empty($worker->resume)): ?>
                        <?php $__currentLoopData = $worker->resume?->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($skill->name); ?> ،
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                    <?php endif; ?>
                    
                </td>

                

                <td class="px-6 py-4">
                    <?php echo e($worker->average_rating); ?>

                </td>

                <td class="px-6 py-4">
                    <?php echo e($worker->accepted_orders_count); ?>

                </td>

                <td class="px-6 py-4">
                    <?php echo e($worker->completed_orders_count); ?>

                </td>

                <td class="px-6 py-4">
                    <?php echo e($worker->resume->commission_rate); ?> درصد
                </td>

                <td class="px-6 py-4 text-center">
                    <?php if($order->workers->contains($worker->id)): ?>
                    <button type="submit" disabled class="bg-green-100 py-1 px-4 text-green-600 opacity-70 text-xs rounded-full font-semibold transition-all duration-200">
                        ارجاع شده
                    </button>
                    <?php elseif($worker->resume->commission_rate == 0): ?>
                    <button type="submit" disabled class="bg-yellow-100 py-1 px-4 text-yellow-600 opacity-70 text-xs rounded-full font-semibold transition-all duration-200">
                         درصد کمیسیون مشخص نشده
                    </button>
                    <?php else: ?>

                    <?php if (isset($component)) { $__componentOriginal055e89981d4790882fe0f81782789986 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal055e89981d4790882fe0f81782789986 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.utils.modal','data' => ['title' => 'توضیحات اپراتور','btnTitle' => 'ارجاع','btnColor' => 'bg-gray-200 border border-gray-300']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('utils.modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'توضیحات اپراتور','btnTitle' => 'ارجاع','btnColor' => 'bg-gray-200 border border-gray-300']); ?>
                        <div>
                            <form action="<?php echo e(route('admin.orders.assignToWorkers', $order)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="worker_id" value="<?php echo e($worker->id); ?>">
                                <textarea name="operator_notes" rows="4" class="w-full p-5 rounded-lg  bg-gray-50 text-gray-700 duration-200 border border-gray-200  focus:border-blue-300 outline-none text-lg"></textarea>
                                
                                <button type="submit" class="mr-auto mt-3 flex items-center gap-x-2 text-white bg-blue-500 hover:bg-blue-600 duration-200 rounded-lg text-sm px-4 py-2 ">
                                    ارجاع
                                    <svg class="fill-white" width="15" height="15" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l160 160c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L109.2 288 416 288c17.7 0 32-14.3 32-32s-14.3-32-32-32l-306.7 0L214.6 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-160 160z"/></svg> 
                                </button>
                            </form>
                        </div>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal055e89981d4790882fe0f81782789986)): ?>
<?php $attributes = $__attributesOriginal055e89981d4790882fe0f81782789986; ?>
<?php unset($__attributesOriginal055e89981d4790882fe0f81782789986); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal055e89981d4790882fe0f81782789986)): ?>
<?php $component = $__componentOriginal055e89981d4790882fe0f81782789986; ?>
<?php unset($__componentOriginal055e89981d4790882fe0f81782789986); ?>
<?php endif; ?>
                   
                    <?php endif; ?>
                   
                    
                </td>
                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
           
        </tbody>
    </table>  

    <div class="mt-4">
        <?php echo e($workers->links()); ?>

    </div> 

    
    
    
    

</div>

                                            
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\group_cleaning\groupCleaning_back\resources\views/management/orders/assignToWorker.blade.php ENDPATH**/ ?>