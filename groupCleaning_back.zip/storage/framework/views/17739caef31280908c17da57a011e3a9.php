<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"> 
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://unpkg.com/@majidh1/jalalidatepicker/dist/jalalidatepicker.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <title><?php echo e($title ?? 'پنل مدیریت'); ?></title>

    <?php if (isset($component)) { $__componentOriginald0e2077160a11f028ac992bd4d62bc48 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0e2077160a11f028ac992bd4d62bc48 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.head.tinymce-config','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head.tinymce-config'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0e2077160a11f028ac992bd4d62bc48)): ?>
<?php $attributes = $__attributesOriginald0e2077160a11f028ac992bd4d62bc48; ?>
<?php unset($__attributesOriginald0e2077160a11f028ac992bd4d62bc48); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0e2077160a11f028ac992bd4d62bc48)): ?>
<?php $component = $__componentOriginald0e2077160a11f028ac992bd4d62bc48; ?>
<?php unset($__componentOriginald0e2077160a11f028ac992bd4d62bc48); ?>
<?php endif; ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>
<body>
     
    

    <div class="px-1 lg:px-4">
        
        <?php if(session()->has('error')): ?>
        <div class="bg-red-200 text-red-600 rounded p-3 mt-3">
            <?php echo e(session('error')); ?>

        </div>
        <?php endif; ?>

        <div class="py-12 flex gap-x-6">
            <?php if($showSidebar ?? true): ?>
                <?php if (isset($component)) { $__componentOriginal6702637fcda68559f293a0e6ab31b9f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6702637fcda68559f293a0e6ab31b9f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar.admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6702637fcda68559f293a0e6ab31b9f6)): ?>
<?php $attributes = $__attributesOriginal6702637fcda68559f293a0e6ab31b9f6; ?>
<?php unset($__attributesOriginal6702637fcda68559f293a0e6ab31b9f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6702637fcda68559f293a0e6ab31b9f6)): ?>
<?php $component = $__componentOriginal6702637fcda68559f293a0e6ab31b9f6; ?>
<?php unset($__componentOriginal6702637fcda68559f293a0e6ab31b9f6); ?>
<?php endif; ?>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <script type="text/javascript" src="https://unpkg.com/@majidh1/jalalidatepicker/dist/jalalidatepicker.min.js"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html><?php /**PATH D:\group_cleaning\groupCleaning_back\resources\views/layouts/admin.blade.php ENDPATH**/ ?>